export const numberToBanglaWords = (num: number): string => {
  if (!Number.isFinite(num)) {
    throw new Error("Invalid number");
  }

  if (num === 0) return "শূন্য";

  if (num < 0) {
    return `ঋণাত্মক ${numberToBanglaWords(Math.abs(num))}`;
  }

  // Decimal number handle
  if (!Number.isInteger(num)) {
    const [integerPart, decimalPart] = num.toString().split(".");

    const decimalWords = decimalPart
      .split("")
      .map((digit) => digitToBanglaWord(Number(digit)))
      .join(" ");

    return `${numberToBanglaWords(Number(integerPart))} দশমিক ${decimalWords}`;
  }

  const ones = [
    "",
    "এক",
    "দুই",
    "তিন",
    "চার",
    "পাঁচ",
    "ছয়",
    "সাত",
    "আট",
    "নয়",
  ];

  // Exact Bengali number words from 10 to 99
  const belowHundred: Record<number, string> = {
    10: "দশ",
    11: "এগারো",
    12: "বারো",
    13: "তেরো",
    14: "চৌদ্দ",
    15: "পনেরো",
    16: "ষোলো",
    17: "সতেরো",
    18: "আঠারো",
    19: "উনিশ",

    20: "বিশ",
    21: "একুশ",
    22: "বাইশ",
    23: "তেইশ",
    24: "চব্বিশ",
    25: "পঁচিশ",
    26: "ছাব্বিশ",
    27: "সাতাশ",
    28: "আঠাশ",
    29: "ঊনত্রিশ",

    30: "ত্রিশ",
    31: "একত্রিশ",
    32: "বত্রিশ",
    33: "তেত্রিশ",
    34: "চৌত্রিশ",
    35: "পঁয়ত্রিশ",
    36: "ছত্রিশ",
    37: "সাঁইত্রিশ",
    38: "আটত্রিশ",
    39: "ঊনচল্লিশ",

    40: "চল্লিশ",
    41: "একচল্লিশ",
    42: "বিয়াল্লিশ",
    43: "তেতাল্লিশ",
    44: "চুয়াল্লিশ",
    45: "পঁয়তাল্লিশ",
    46: "ছেচল্লিশ",
    47: "সাতচল্লিশ",
    48: "আটচল্লিশ",
    49: "ঊনপঞ্চাশ",

    50: "পঞ্চাশ",
    51: "একান্ন",
    52: "বাহান্ন",
    53: "তিপ্পান্ন",
    54: "চুয়ান্ন",
    55: "পঞ্চান্ন",
    56: "ছাপ্পান্ন",
    57: "সাতান্ন",
    58: "আটান্ন",
    59: "ঊনষাট",

    60: "ষাট",
    61: "একষট্টি",
    62: "বাষট্টি",
    63: "তেষট্টি",
    64: "চৌষট্টি",
    65: "পঁয়ষট্টি",
    66: "ছেষট্টি",
    67: "সাতষট্টি",
    68: "আটষট্টি",
    69: "ঊনসত্তর",

    70: "সত্তর",
    71: "একাত্তর",
    72: "বাহাত্তর",
    73: "তিয়াত্তর",
    74: "চুয়াত্তর",
    75: "পঁচাত্তর",
    76: "ছিয়াত্তর",
    77: "সাতাত্তর",
    78: "আটাত্তর",
    79: "ঊনআশি",

    80: "আশি",
    81: "একাশি",
    82: "বিরাশি",
    83: "তিরাশি",
    84: "চুরাশি",
    85: "পঁচাশি",
    86: "ছিয়াশি",
    87: "সাতাশি",
    88: "আটাশি",
    89: "ঊননব্বই",

    90: "নব্বই",
    91: "একানব্বই",
    92: "বিরানব্বই",
    93: "তিরানব্বই",
    94: "চুরানব্বই",
    95: "পঁচানব্বই",
    96: "ছিয়ানব্বই",
    97: "সাতানব্বই",
    98: "আটানব্বই",
    99: "নিরানব্বই",
  };

  const digitToBanglaWord = (digit: number): string => {
    return ones[digit] || "";
  };

  const convertBelowHundred = (n: number): string => {
    if (n < 10) {
      return ones[n];
    }

    return belowHundred[n];
  };

  const convertBelowThousand = (n: number): string => {
    if (n < 100) {
      return convertBelowHundred(n);
    }

    const hundred = Math.floor(n / 100);
    const remainder = n % 100;

    let result = `${ones[hundred]} শত`;

    if (remainder > 0) {
      result += ` ${convertBelowHundred(remainder)}`;
    }

    return result;
  };

  const parts: string[] = [];

  // কোটি
  const crore = Math.floor(num / 10_000_000);

  if (crore > 0) {
    parts.push(`${convertBelowThousand(crore)} কোটি`);
    num %= 10_000_000;
  }

  // লক্ষ
  const lakh = Math.floor(num / 100_000);

  if (lakh > 0) {
    parts.push(`${convertBelowThousand(lakh)} লক্ষ`);
    num %= 100_000;
  }

  // হাজার
  const thousand = Math.floor(num / 1_000);

  if (thousand > 0) {
    parts.push(`${convertBelowThousand(thousand)} হাজার`);
    num %= 1_000;
  }

  // শত / দশ / একক
  if (num > 0) {
    parts.push(convertBelowThousand(num));
  }

  return parts.join(" ");
};
